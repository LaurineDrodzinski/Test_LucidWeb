window.GLOBAL = {};
window.THREE = require("../lib/vendor/three.js");

(function(){
	"use strict";

	//Objets
	var cube=undefined;
	var sphere=undefined;
	var cone=undefined;
	var torus=undefined;
	var obj=undefined;//Permet de savoir quel objet est affiché

	//Pour déplacer l'objet
	var sensTranslationX=0;
	var sensTranslationY=0;
	var sensTranslationZ=0;

	//Pour déplacer la caméra
	var right, up, at;//Pour extraire les axes de la matrice de transformation de la caméra
	var directions = {};
		directions.forward = false;
		directions.backward = false;
		directions.left = false;
		directions.right = false;

	//Pour tourner l'objet
	var mouseX = 0;//Coordonnées de la souris
	var mouseY = 0;//Coordonnées de la souris
	var espaceDown = false;//Permet d'activer la rotation

	var	shift=false;//Permet d'alterner entre déplacement caméra/objet

	var windowHalfX = window.innerWidth / 2;
	var windowHalfY = window.innerHeight / 2;

	var World = require("../lib/intern/world.js");
	var THREE = require("../lib/vendor/three.js");

	GLOBAL.env = (location.href.indexOf("3000") !== -1 || location.href.indexOf("debug=true") !== -1 ? "dev" : "prod");

	var world = new World({
		color : 0x999999,
		fov   : 70,
		near  : 0.1,
		far   : 10000
	});
	world.getRenderer().domElement.className = "mainCanvas";
	world.getRenderer().domElement.id        = "mainCanvas";
	GLOBAL.world = world;

	/*Création des vecteurs*/
  	right = new THREE.Vector3();
    up = new THREE.Vector3();
    at = new THREE.Vector3();
    world.getCamera().matrix.extractBasis(right,up,at);//Extraction des données

	/*Skybox*/
	var boxWidth = 20 ;
	var geometry = new THREE.BoxGeometry(boxWidth, boxWidth, boxWidth);//Type d'objet
	var texture = new THREE.TextureLoader().load( 'public/assets/fond.jpg' );//Texture
	var material = new THREE.MeshPhongMaterial( { map: texture, color : 0x555555, side:THREE.BackSide} );//Application de la texture
	material.bumpMap    = texture;
	material.bumpScale = 0.03;//Volume de la texture
	var skybox = new THREE.Mesh(geometry, material);//Création de l'objet
	world.getScene().add(skybox);//Ajout de l'objet à la scène

	/*Lumières****/
	var light1 = new THREE.PointLight( 0xffffff, 0.6, 100 );
	light1.position.set( -2, 2, 1 );
	world.getScene().add(light1);

	var light2 = new THREE.PointLight( 0xffffff, 0.6, 100 );
	light2.position.set( 2, -2, 1 );
	world.getScene().add(light2);

	var light3 = new THREE.PointLight( 0xffffff, 0.6, 100 );
	light3.position.set( 2, 2, 1 );
	world.getScene().add(light3);

	var light4 = new THREE.PointLight( 0xffffff, 0.6, 100 );
	light4.position.set( -2, -2, 1 );
	world.getScene().add(light4);

	// Create 3D objects.
	var geometry = new THREE.BoxGeometry(0.5, 0.5, 0.5);
	var texture = new THREE.TextureLoader().load( 'public/assets/cube.png' );
	var material = new THREE.MeshPhongMaterial( { map: texture } );
	material.bumpMap    = texture;
	material.bumpScale = 0.05;
	cube = new THREE.Mesh(geometry, material);
	
	// Rotation cube mesh
	cube.rotation.x = Math.random() * 2 * Math.PI;
	cube.rotation.y = Math.random() * 2 * Math.PI;
	cube.rotation.z = Math.random() * 2 * Math.PI;

	// Position cube mesh
	cube.position.z = -1.3;
	obj=cube;
	obj.scale.x=0.77;		
	obj.scale.y=0.77;		
	obj.scale.z=0.77;
	obj.position.x=0;		
	obj.position.y=0;		
	obj.position.z=-1;

	// Add cube mesh to your three.js scene
	world.getScene().add(cube);

	world.hookOnPreRender(function(){
		//Déplacement de l'objet
		if (sensTranslationY != 0 || sensTranslationX != 0 || sensTranslationZ != 0) {
			obj.position.set(
				obj.position.x+sensTranslationX, 
				obj.position.y+sensTranslationY, 
				obj.position.z+sensTranslationZ 
			);
			sensTranslationY=0;//Evite le déplacement de l'objet quand on ne touche plus à la molette
		}

		//Déplacement de la caméra
    	world.getCamera().matrix.extractBasis(right,up,at);
    	if(directions.forward) {
       	 	world.getCamera().position.add(at.multiplyScalar(-0.03));
    	}
    	if(directions.backward) {
       	 	world.getCamera().position.add(at.multiplyScalar(0.03));
    	}
    	if(directions.left) {
        	world.getCamera().position.add(right.multiplyScalar(-0.03));
    	}
    	if(directions.right) {
        	world.getCamera().position.add(right.multiplyScalar(0.03));
   		}

		//Rotation de l'objet
		if(espaceDown){
			obj.rotation.x =  mouseY * Math.PI / 280;
			obj.rotation.y =  mouseX * Math.PI / 280;
		}

	});

	window.addEventListener('mousemove', onMouseMove, false ); 
	window.addEventListener("keydown", onKeyDown, false);
    window.addEventListener("keyup", onKeyUp, false);
    window.addEventListener("mousemove", onMouseMove, false);
    window.addEventListener("wheel", onWheel, false);

	// Kick off animation loop
	world.start();

	function onKeyDown(evt) {

		switch(evt.keyCode) {

			case 90: //z
				if(shift){//Déplacement de la caméra
          			directions.forward = true;	
				}else{//Déplacement de l'objet
					sensTranslationZ=-0.02;
				}
			break;

			case 81: //q
				if(shift){	
           			directions.left = true;
				}else{
					sensTranslationX=-0.02;
				}
			break;

			case 83: //s
				if(shift){
            		directions.backward = true;	
				}else{
					sensTranslationZ=0.02;
				}
			break;

			case 68: //d
				if(shift){	
            		directions.right = true;
				}else{
					sensTranslationX=0.02;
				}
			break;

			case 32://space
				espaceDown=true;
			break;

		}
	}

	function onKeyUp(evt) {

		switch(evt.keyCode) {

			case 90://z
				sensTranslationZ=0;
            	directions.forward = false;
			break;

			case 81://q 
				sensTranslationX=0;
            	directions.left = false;
			break;

			case 83://s
				sensTranslationZ=0;
            	directions.backward = false;
			break;

			case 68://d
				sensTranslationX=0;
            	directions.right = false;
			break;

			case 32://space
				espaceDown=false;
			break;

			case 16://shift
				shift=!shift;
				//Indique à l'utilisateur s'il est en mode "déplacement de la caméra" ou "déplacement de l'objet"
				if(shift){//S'il est en mode "déplacement de l'objet"
					document.getElementById('imgMove').src='../public/assets/cam.png';
				}else{//S'il est en mode "déplacement de la caméra"
					document.getElementById('imgMove').src='../public/assets/cub.png';
				}
			break;
		}
	}

	function onWheel(evt) {
		if(!shift){
			if(evt.deltaY>0){
				sensTranslationY=-0.04;
			}else{
				sensTranslationY=0.04;
			}
		}
	}

	function onMouseMove(evt) {
		mouseX = evt.clientX - windowHalfX;
		mouseY = evt.clientY - windowHalfY;
	}

	document.getElementById('btnSphere').onclick = function(){
		if(sphere==undefined){
			var geometry = new THREE.SphereGeometry(0.3,32,32);
			var texture = new THREE.TextureLoader().load( 'public/assets/deathStars.jpg' );
			var material = new THREE.MeshPhongMaterial( { map: texture } );
			material.bumpMap = texture;
			material.bumpScale = 0.03;
			sphere = new THREE.Mesh(geometry, material);

			sphere.rotation.x = Math.random() * 2 * Math.PI;
			sphere.rotation.y = Math.random() * 2 * Math.PI;
			sphere.rotation.z = Math.random() * 2 * Math.PI;
		}

		sphere.position.x=obj.position.x;
		sphere.position.y=obj.position.y;
		sphere.position.z=obj.position.z;

		sphere.scale.x=obj.scale.x;
		sphere.scale.y=obj.scale.y;
		sphere.scale.z=obj.scale.z;

		world.getScene().remove( obj );
		world.getScene().add( sphere );
		obj=sphere;
	}

	document.getElementById('btnCube').onclick = function(){
		cube.position.x=obj.position.x;
		cube.position.y=obj.position.y;
		cube.position.z=obj.position.z;

		cube.scale.x=obj.scale.x;
		cube.scale.y=obj.scale.y;
		cube.scale.z=obj.scale.z;

		world.getScene().remove( obj );	
		world.getScene().add( cube );
		obj=cube;
	}

	document.getElementById('btnCone').onclick = function(){
		if(cone==undefined){
			var geometry = new THREE.ConeGeometry(0.2,0.5,15);
			var texture = new THREE.TextureLoader().load( 'public/assets/cone.jpg' );
			var material = new THREE.MeshPhongMaterial( { map: texture } );
			material.bumpMap    = texture;
			material.bumpScale = 0.03;
			cone     = new THREE.Mesh(geometry, material);

			cone.rotation.x = Math.random() * 2 * Math.PI;
			cone.rotation.y = Math.random() * 2 * Math.PI;
			cone.rotation.z = Math.random() * 2 * Math.PI;
		}

		cone.position.x=obj.position.x;
		cone.position.y=obj.position.y;
		cone.position.z=obj.position.z;

		cone.scale.x=obj.scale.x;
		cone.scale.y=obj.scale.y;
		cone.scale.z=obj.scale.z;

		world.getScene().remove( obj );	
		world.getScene().add( cone );
		obj=cone;
	}


	document.getElementById('btnTorusKnot').onclick = function(){
		if(torus==undefined){
			var geometry = new THREE.TorusKnotGeometry( 0.2, 0.05, 0.5, 0.5 );
			var texture = new THREE.TextureLoader().load( 'public/assets/snake.jpg' );
			var material = new THREE.MeshPhongMaterial( { map: texture } );
			material.bumpMap    = texture;
			material.bumpScale = 0.02;
			torus = new THREE.Mesh( geometry, material );

			torus.rotation.x = Math.random() * 2 * Math.PI;
			torus.rotation.y = Math.random() * 2 * Math.PI;
			torus.rotation.z = Math.random() * 2 * Math.PI;
		}

		torus.position.x=obj.position.x;
		torus.position.y=obj.position.y;
		torus.position.z=obj.position.z;

		torus.scale.x=obj.scale.x;
		torus.scale.y=obj.scale.y;
		torus.scale.z=obj.scale.z;

		world.getScene().remove( obj );	
		world.getScene().add( torus );
		obj=torus;
	}

	document.getElementById('btnMoins').onclick = function(){
		if(obj.scale.x>0.5 && obj.scale.y>0.5 && obj.scale.z>0.5){
			obj.scale.x=obj.scale.x-0.5;		
			obj.scale.y=obj.scale.y-0.5;		
			obj.scale.z=obj.scale.z-0.5;		
		}
	}

	document.getElementById('btnPlus').onclick = function(){
		if(obj.scale.x<15 && obj.scale.y<15 && obj.scale.z<15){
			obj.scale.x=obj.scale.x+0.5;		
			obj.scale.y=obj.scale.y+0.5;		
			obj.scale.z=obj.scale.z+0.5;		
		}
	}

	document.getElementById('btnReset').onclick = function(){
			obj.scale.x=0.77;		
			obj.scale.y=0.77;		
			obj.scale.z=0.77;
			obj.position.x=0;		
			obj.position.y=0;		
			obj.position.z=-1;
	}

})();

