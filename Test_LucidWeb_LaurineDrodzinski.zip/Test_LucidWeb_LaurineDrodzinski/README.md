# webvrStarter

A starter guide to have a working project in WebVR.

Demo: https://tbalouet.github.io/webvrStarter/

To get started run
```
  npm install
  npm run dev
  //or
  npm run prod
```

Before putting in production mode, run
```
  npm run build
```
to generate the uglified file


Site available on http://localhost:3000 (dev env) or http://localhost:80 (prod env)